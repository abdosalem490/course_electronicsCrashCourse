
Thank you for trying our SNXC C Compiler for Ubicom (formerly Scenix) microcontrollers.

Please follow these step to install the license key.

1. After installing the software click on the "Edit" menu in the top bar.
2. Slect the "Configuration" menu.
3. Click on the "KEY:" button
4. A dialog box will appear.  
6. select the "demo_license.txt" file.  If you used the default installation, this file
	is located in C:\Program Files\Grich RC Inc\SnXC C Compiler\demo_license.txt

You are now ready to start compiling C programs for the SX family of microcontrollers.

The docs directory contains a pdf file with the users manual.
The src directory contains example code - start with the blink.c program.  Very simple, easy
to follow and to get started.

To open a file click on "File|Open" menu.  Then navigate to C:\Program Files\Grich RC Inc\SnXC C Compiler\src
directory.  ALL source files MUST be in this directory.

We hope you find our product a very competitive one!!!