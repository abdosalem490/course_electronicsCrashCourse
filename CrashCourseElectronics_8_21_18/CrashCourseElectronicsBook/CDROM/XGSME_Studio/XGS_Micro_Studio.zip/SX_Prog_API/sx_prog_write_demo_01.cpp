/*
    SX Programming API Demo

    Writing to the SX52

    by Alex Varanese
    10.7.2003
*/

#include "sx_prog_api_01.h"

main ()
{
    printf ( "SX PROGRAMMER DEMO" );
    printf ( "\n" );

    // **** INITIALIZE ********************************************************

    // First, initialize the library itself
    SX_Init ( SX_DEVICE_SX52, "" );

    // Now, attempt to initialize the programming mode
    if ( SX_CMD_FAILED ( SX_Init_ISP () ) )
    {
        printf ( "\nCould not initialize ISP mode.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nISP mode initialized." );
    } // End if

    // **** PROGRAM/READ/CONFIGURE ********************************************

    // Load the racing demo as an example
    if ( SX_Load_SXH_File ( "racer.sxh" ) != true )
    {
        printf ( "\nCould not load object code file.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nObject code file loaded." );
    } // End if

    printf ( "\n" );
    printf ( "\nPROGRAMMING CHIP..." );
    printf ( "\n" );

    // Erase the device of any current data
    if ( SX_CMD_FAILED ( SX_Erase_Device () ) == true )
    {
        printf ( "\nCould not erase device.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nDevice erased." );
    } // End if

    // Write the FUSE register
    if ( SX_CMD_FAILED ( SX_Write_FUSE () ) == true )
    {
        printf ( "\nCould not write FUSE register.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nFUSE register written." );
    } // End if

    // Write the program

    printf ( "\nWriting program" );

    bool is_done = false;
    while ( is_done == false )
    {
        // Progress and result
        int    p;
        SX_CMD r;

        // Write the next chunk of the program
        is_done = SX_Write_Program ( &p, &r );

        // Write the next chunk of the program
        if ( SX_CMD_FAILED ( r ) )
        {
            printf ( "\nCould not write to program memory.\n" );
            return ( 0 );
        } // End if

        printf ( ".", p );
    } // End for

    printf ( "\nDevice programmed." );

    // Write the FUSEX register
    if ( SX_CMD_FAILED ( SX_Write_FUSEX () ) == true )
    {
        printf ( "\nCould not write FUSEX register.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nFUSEX register written." );
    } // End if

    // **** SHUT DOWN *********************************************************

    // Shut down the ISP mode
    if ( SX_CMD_FAILED ( SX_Shut_Down_ISP () ) )
    {
        printf ( "\nCould not shut down ISP mode.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nISP mode shut down." );
    } // End if

    printf ( "\n" );

    // Finally, shut the library down
    SX_Shut_Down ();

    return ( 0 );
} // End main ()
