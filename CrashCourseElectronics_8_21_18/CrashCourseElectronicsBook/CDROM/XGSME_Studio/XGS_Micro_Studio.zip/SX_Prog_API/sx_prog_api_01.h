/*
    SX Programming API

    by Alex Varanese
    5.11.2003

    Main header file.
*/

#ifndef SX_PROG_API_H
#define SX_PROG_API_H

// **** INCLUDES **************************************************************

#include <stdio.h>
#include <conio.h>
#include <windows.h>
#include "winio.h"

// **** CONSTANTS *************************************************************

// SX devices
#define SX_DEVICE_SX18              0
#define SX_DEVICE_SX20              1
#define SX_DEVICE_SX28              2
#define SX_DEVICE_SX48              3
#define SX_DEVICE_SX52              4

#define SX_MEM_182028               2048
#define SX_MEM_4852                 4096

#define MAX_PROGRAM_RUN_COUNT       1024

// SX DEVICE register codes
#define SX_DEVICE_REG_SX182028      0xFCE               // 18, 20, 28 - 111111001110
#define SX_DEVICE_REG_SX4852        0x002               // 48, 52     - 000000000010

// FUSE Pin Masks
#define FUSE_28_PIN_nTURBO          2048
#define FUSE_28_PIN_nSYNC           1024
#define FUSE_28_PIN_nIRC            128
#define FUSE_28_PIN_DIV1_nIFBD      64
#define FUSE_28_PIN_DIV0_FOSC2      32
#define FUSE_28_PIN_nCP             8
#define FUSE_28_PIN_WDTE            4
#define FUSE_28_PIN_FOSC1           2
#define FUSE_28_PIN_FOSC0           1

#define FUSE_52_PIN_nSYNC           1024
#define FUSE_52_PIN_nIRC            128
#define FUSE_52_PIN_DIV1_nIFBD      64
#define FUSE_52_PIN_DIV0_FOSC2      32
#define FUSE_52_PIN_nXTLBUF_EN      16
#define FUSE_52_PIN_nCP             8
#define FUSE_52_PIN_WDTE            4
#define FUSE_52_PIN_FOSC1           2
#define FUSE_52_PIN_FOSC0           1

// FUSEX Pin Masks
#define FUSEX_28_PIN_IRCTRIM2         2048
#define FUSEX_28_PIN_PINS             1024
#define FUSEX_28_PIN_IRCTRIM1         512
#define FUSEX_28_PIN_IRCTRIM0         256
#define FUSEX_28_PIN_nOPTIONX_nSTACKX 128
#define FUSEX_28_PIN_nCF              64
#define FUSEX_28_PIN_BOR1             32
#define FUSEX_28_PIN_BOR0             16
#define FUSEX_28_PIN_BORTRIM1         8
#define FUSEX_28_PIN_BORTRIM0         4
#define FUSEX_28_PIN_BP1              2
#define FUSEX_28_PIN_BP0              1

#define FUSEX_52_PIN_IRCTRIM2       2048
#define FUSEX_52_PIN_nSLEEPCLK      1024
#define FUSEX_52_PIN_IRCTRIM1       512
#define FUSEX_52_PIN_IRCTRIM0       256
#define FUSEX_52_PIN_nCF            64
#define FUSEX_52_PIN_BOR1           32
#define FUSEX_52_PIN_BOR0           16
#define FUSEX_52_PIN_BORTRIM1       8
#define FUSEX_52_PIN_BORTRIM0       4
#define FUSEX_52_PIN_DRT1           2
#define FUSEX_52_PIN_DRT0           1

#define SX_PROGRAM_SIZE             8192                // Size of SX program memory

// Parallel port pins
#define PIN_NULL                    0x00                // All pins off
#define PIN_STROBE                  0x01                // Strobe
#define PIN_CLOCK                   0x02                // Clock
#define PIN_DATA_OUT                0x04                // Data output (to programmer)
#define PIN_DATA_IN                 0x40                // Data input (from programmer)

// Timing
#define DEL_HOLD                    100                 // Length of delay for signal hold times (in microseconds)

// Meta Commands
#define CMD_INIT_ISP		        0x0
#define CMD_SHUT_DOWN_ISP	        0x1
#define CMD_SEND_ISP_CMD	        0x2
#define CMD_RUN_DIAG		        0x3
#define CMD_ENTER_LOOP		        0x4
#define CMD_EXIT_LOOP	            0x5
#define CMD_WRITE_BUFFER            0x6
#define CMD_STREAM_BUFFER_OUT       0x7
#define CMD_READ_BUFFER             0x8
#define CMD_STREAM_BUFFER_IN        0x9
#define CMD_INC_MEM_PTR             0xA

#define CMD_TIMEOUT                 500                 // Length (in ticks) at which a timeout is declared
#define MAX_CMD_RETRY               4                   // Number of times a command is retried before a timeout is official

// SX ISP Commands
#define ISP_CMD_ERASE	            0x0
#define ISP_CMD_READ_DEVICE         0x1
#define ISP_CMD_READ_FUSEX	        0x2
#define ISP_CMD_PROG_FUSEX	        0x3
#define ISP_CMD_LOAD_DATA	        0x4
#define ISP_CMD_PROG_MEM	        0x5
#define ISP_CMD_READ_MEM            0x6
#define ISP_CMD_INC_MEM_PTR         0x7
#define ISP_CMD_NOP	    	        0xF

// Programmer
#define SX_PROG_BUFFER_BYTE_SIZE    64                               // Size of onboard buffer (in bytes)
#define SX_PROG_BUFFER_SIZE         ( SX_PROG_BUFFER_BYTE_SIZE / 2 ) // Size of onboard buffer (in bytes)

// Response Status Codes
#define STATUS_SUCCESS		        0xA                 // Command was successful
#define STATUS_ERROR		        0xB                 // Command failed
#define STATUS_TIMEOUT		        0xD                 // Command failed due to a timeout

// SXH File Format
#define ADDR_FUSE                   0x1010              // Address of FUSE register
#define ADDR_FUSEX                  0x1011              // Address of FUSEX register

// Default configuration settings   

// Repetition counts
#define DEF_REP_LOAD_DATA           1
#define DEF_REP_ERASE               250
#define DEF_REP_PROG_MEM            1
#define DEF_REP_PROG_FUSEX          100
#define DEF_REP_PROG_FUSE           4

// Verification
#define DEF_WRITE_VERIFY_FREQ       16

// **** ALIASES ***************************************************************

typedef int SX_WORD;                                    // 12-bit program memory word
typedef unsigned int SX_CMD;                            // 32-bit command/response packet

// **** STRUCTURES ************************************************************

// Configuration settings
struct SX_PROG_CONFIG
{
    // Rep counts per operation
    int rep_load_data;                                  // Load data register
    int rep_erase;                                      // Erase program memory
    int rep_prog_mem;                                   // Program memory word
    int rep_prog_fusex;                                 // Program FUSEX register
    int rep_prog_fuse;                                  // Program FUSE register

    // Verification
    int write_verify_freq;                              // Frequency of verifications within a program write
}; // End SX_PROG_CONFIG

// Tracks runs of similar code blocks
struct SX_RUN
{
    int  end;                                           // End point of run
    bool is_clear;                                      // Is this a run of clear/blank words?
}; // End SX_RUN

// Encapsulates the SX device
struct SX_DEVICE
{
    // Device identification
    int     type;                                       // Device type
    char    name_string [ 32 ];                         // Device name (example: "SX18")

    // Registers
    SX_WORD fuse, fusex, device;                        // System configuration

    // Program code
    int     program_size;                               // Size of the program memory (in bytes)
    SX_WORD program       [ SX_PROGRAM_SIZE ];          // Program memory
    SX_WORD final_program [ SX_PROGRAM_SIZE ];          // Finalized program memory (write to chip)
    int     run_count;                                  // Number of program runs mapped
    SX_RUN  run_map       [ MAX_PROGRAM_RUN_COUNT ];    // Map of program "runs" (empty gaps in code space)

    // The ISP memory pointer
    int     mem_ptr;                                    // Memory pointer
    int     mem_ptr_moved;                              // Has the memory pointer been moved yet?
}; // End SX_DEVICE

// **** MACROS ****************************************************************

/******************************************************************************
*
*   SX_DETECT_DEVICE_NAME
*
*   Returns the string name based on the DEVICE register.
*/

#define SX_DETECT_DEVICE_NAME ( g_sx_device.device == SX_DEVICE_REG_SX4852 ?         \
                                    "SX48/52" :                                      \
                                    ( g_sx_device.device == SX_DEVICE_REG_SX182028 ? \
                                        "SX18/20/28" :                               \
                                        "Unknown" ) )

/******************************************************************************
*
*   SX_DEC_TO_HEX
*
*   Converts a decimal value to a single hex digit.
*/

#define SX_DEC_TO_HEX( x ) ( ( (x) >= 0 && (x) <= 9 ) ? '0' + (x) : ( ( (x) >= 0xA && (x) <= 0xF ) ? 'A' + ( (x) - 0xA ) : '0' ) )

/******************************************************************************
*
*   Progammer response manipulation macros
*/

#define SX_GET_RESPONSE_DATA( r )   ( r & 0xFFF )
#define SX_GET_RESPONSE_STATUS( r ) ( ( r & 0xF0000000 ) >> 28 )
#define SX_CMD_FAILED( r )          ( ( ( r & 0xF0000000 ) >> 28 ) != STATUS_SUCCESS ? true : false )

/******************************************************************************
*
*   Bit manipulation macros
*/

// Bit masks
#define BIT_0               1
#define BIT_1               2
#define BIT_2               4
#define BIT_3               8
#define BIT_4               16
#define BIT_5               32
#define BIT_6               64
#define BIT_7               128
#define BIT_8               256
#define BIT_9               512
#define BIT_10              1024
#define BIT_11              2048
#define BIT_12              4096
#define BIT_13              8192
#define BIT_14              16384
#define BIT_15              32768

#define SET_BIT( x, bit_mask )    ( x = ( x | bit_mask ) )
#define CLEAR_BIT( x, bit_mask )  ( x = ( x & ( ~bit_mask ) ) )
#define INVERT_BIT( x, bit_mask ) ( x = ( x ^ bit_mask ) )   
#define READ_BIT( x, bit_mask )   ( x & bit_mask ? TRUE : FALSE )

// **** PROTOTYPES ************************************************************

// Internal helper functions
SX_CMD Send_Prog_Cmd ( unsigned int meta_cmd,
                       unsigned int rep_count,
                       unsigned int isp_cmd,
                       unsigned int isp_data,
                       unsigned int buffer_data,
                       unsigned int buffer_address );
void   Delay_us      ( int del );
int    Get_Hex_Digit ( char x );

// SX Programming API
bool   SX_Init              ( int device, char *config_file );
bool   SX_Shut_Down         ();
void   SX_Set_Device        ( int device );
SX_CMD SX_Init_ISP          ();
SX_CMD SX_Shut_Down_ISP     ();
void   SX_Erase_Buffer      ();
void   SX_Map_Code_Runs     ();
bool   SX_Load_SXH_File     ( char *filename );
bool   SX_Save_SXH_File     ( char *filename );
bool   SX_Read_Program      ( int *progress, SX_CMD *result );
bool   SX_Write_Program     ( int *progress, SX_CMD *result );
SX_CMD SX_Erase_Device      ();
SX_CMD SX_Inc_Mem_Ptr       ( int count );
SX_CMD SX_Read              ();
SX_CMD SX_Write             ( SX_WORD x, bool verify );
SX_CMD SX_Read_FUSE         ();
SX_CMD SX_Write_FUSE        ();
SX_CMD SX_Read_FUSEX        ();
SX_CMD SX_Write_FUSEX       ();
SX_CMD SX_Read_DEVICE       ();
SX_CMD SX_Write_Buffer      ( SX_WORD data, int addr );
SX_CMD SX_Read_Buffer       ( int addr );
SX_CMD SX_Stream_Buffer_Out ( int size );
SX_CMD SX_Stream_Buffer_In  ( int size );

// **** EXTERNALS *************************************************************

extern SX_PROG_CONFIG g_sx_config;
extern SX_DEVICE      g_sx_device;
extern int            g_lpt_out, g_lpt_in, g_lpt_control;

#endif