/*
    SX Programming API Demo

    Reading from the SX52

    by Alex Varanese
    10.7.2003
*/

#include "sx_prog_api_01.h"

main ()
{
    printf ( "SX PROGRAMMER DEMO" );
    printf ( "\n" );

    // **** INITIALIZE ********************************************************

    // First, initialize the library itself
    SX_Init ( SX_DEVICE_SX52, "" );

    // Now, attempt to initialize the programming mode
    if ( SX_CMD_FAILED ( SX_Init_ISP () ) )
    {
        printf ( "\nCould not initialize ISP mode.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nISP mode initialized." );
    } // End if

    // **** PROGRAM/READ/CONFIGURE ********************************************

    printf ( "\n" );
    printf ( "\nREADING CHIP..." );
    printf ( "\n" );

    // Read the DEVICE register
    if ( SX_CMD_FAILED ( SX_Read_DEVICE () ) == true )
    {
        printf ( "\nCould not read DEVICE register.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nDEVICE register read." );
    } // End if

    // Read the FUSE register
    if ( SX_CMD_FAILED ( SX_Read_FUSE () ) == true )
    {
        printf ( "\nCould not read FUSE register.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nFUSE register read." );
    } // End if

    printf ( "\nReading program" );

    bool is_done = false;
    while ( is_done == false )
    {
        // Progress and result
        int    p;
        SX_CMD r;

        // Write the next chunk of the program
        is_done = SX_Read_Program ( &p, &r );

        // Write the next chunk of the program
        if ( SX_CMD_FAILED ( r ) )
        {
            printf ( "\nCould not read from program memory.\n" );
            return ( 0 );
        } // End if

        printf ( ".", p );
    } // End for

    printf ( "\nDevice read." );

    // Read the FUSEX register
    if ( SX_CMD_FAILED ( SX_Read_FUSEX () ) == true )
    {
        printf ( "\nCould not read FUSEX register.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nFUSEX register read." );
    } // End if

    // Print out registers
    printf ( "\n" );
    printf ( "\nFUSE:   $%03X", g_sx_device.fuse );
    printf ( "\nFUSEX:  $%03X", g_sx_device.fusex );
    printf ( "\nDEVICE: $%03X", g_sx_device.device );
    printf ( "\n" );

    // Save the read file
    if ( SX_Save_SXH_File ( "program.sxh" ) != true )
    {
        printf ( "\nCould not save object code file.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nObject code file saved." );
    } // End if

    // **** SHUT DOWN *********************************************************

    // Shut down the ISP mode
    if ( SX_CMD_FAILED ( SX_Shut_Down_ISP () ) )
    {
        printf ( "\nCould not shut down ISP mode.\n" );
        return ( 0 );
    }
    else
    {
        printf ( "\nISP mode shut down." );
    } // End if

    printf ( "\n" );

    // Finally, shut the library down
    SX_Shut_Down ();

    return ( 0 );
} // End main ()
