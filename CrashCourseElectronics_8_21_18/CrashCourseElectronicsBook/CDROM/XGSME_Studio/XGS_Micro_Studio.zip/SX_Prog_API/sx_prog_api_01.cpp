/*
    SX Programming API

    by Alex Varanese
    5.11.2003

    Main implementation file.
*/

// **** INCLUDES **************************************************************

#include "sx_prog_api_01.h"

// **** GLOBALS ***************************************************************

// Configuration settings
SX_PROG_CONFIG g_sx_config;

// Physical hardware
SX_DEVICE g_sx_device;                                  // Currently described device

// Library state/status
int g_lib_init = 0;                                     // Has the library been initialized yet?
int g_isp_init = 0;                                     // Has ISP mode been initialized yet?

// Parallel port
int g_lpt_out, g_lpt_in, g_lpt_control;                 // Parallel port addresses

// Timing
unsigned int g_del_ms, g_del_us;

// **** FUNCTIONS *************************************************************

/******************************************************************************
*
*   Send_Prog_Cmd ()
*
*   Sends a command to the programmer.
*/

SX_CMD Send_Prog_Cmd ( unsigned int meta_cmd,
                       unsigned int rep_count,
                       unsigned int isp_cmd,
                       unsigned int isp_data,
                       unsigned int buffer_data,
                       unsigned int buffer_address )
{
    int           i;                                    // Index
    SX_CMD        packet_out = 0,                       // Command/response packets
                  packet_in  = 0;
    unsigned long inp;

    // **** CREATE PACKET *****************************************************

    // Is this a buffer read/write command?
    if ( meta_cmd == CMD_READ_BUFFER ||
         meta_cmd == CMD_WRITE_BUFFER )
    {
        // Write Buffer Data to [11..0] of the packet
        packet_out = buffer_data;

        // Write Address to [19..12] of the packet
        packet_out |= ( buffer_address << 12 );

        // Write Meta Command to [31..28] of the packet
        packet_out |= ( meta_cmd << 28 );
    }
    else
    {
        // Write ISP Data to [11..0] of the packet
        packet_out = isp_data;

        // Write ISP Command to [15..12] of the packet
        packet_out |= ( isp_cmd << 12 );

        // Write Rep Count to [27..16] of the packet
        packet_out |= ( rep_count << 16 );

        // Write Meta Command to [31..28] of the packet
        packet_out |= ( meta_cmd << 28 );
    } // End if

    // **** WRITE PACKET TO PROGRAMMER ****************************************

    // Attempt to send the command and get a response in a loop until the
    // response comes back.
    bool timeout = true;                            // Assume a timeout will occur
    for ( int retry = 0; retry < MAX_CMD_RETRY; retry++ )
    {
        int failed = false;                         // Did this attempt fail?

        // Pull the strobe line low to indicate a pending packet
        SetPortVal ( g_lpt_out, PIN_NULL, 1 );      // Lower the signal
        Delay_us   ( DEL_HOLD );                    // Hold
        SetPortVal ( g_lpt_out, PIN_STROBE, 1 );    // Raise it up again

        // Begin sending the commmand to the programmer
        unsigned int mask = 0x80000000;             // Mask out all but the first bit
        for ( i = 0; i < 32; i++ )
        {
            // Put the next bit on the Data Out line
            if ( ( packet_out & mask ) != 0 )
            {
                SetPortVal ( g_lpt_out, PIN_DATA_OUT, 1 );             // Write the bit
                Delay_us   ( DEL_HOLD );                               // Hold
                SetPortVal ( g_lpt_out, PIN_DATA_OUT | PIN_CLOCK, 1 ); // Clock programmer
                Delay_us   ( DEL_HOLD );                               // Hold
            }
            else
            {
                SetPortVal ( g_lpt_out, PIN_NULL, 1 );  // Write nothing
                Delay_us   ( DEL_HOLD );                // Hold
                SetPortVal ( g_lpt_out, PIN_CLOCK, 1 ); // Clock programmer
                Delay_us   ( DEL_HOLD );                // Hold
            } // End if

            SetPortVal ( g_lpt_out, PIN_NULL, 1 );    // Clear the clock
            Delay_us   ( DEL_HOLD );                  // Hold

            // Shift the mask to the next bit
            mask >>= 1;
        } // End while
    
        // **** WAIT FOR RESPONSE AND READ FROM PROGRAMMER ********************

        // Reset the start of the operation
        int start_time = GetTickCount ();

        // Wait for the Data Out line to go high
        while ( true )
        {
            GetPortVal ( g_lpt_in, &inp, 1 );
            if ( ( inp & PIN_DATA_IN ) != 0 ) break;

            // If the elapased exceeds the minimum timeout time, try again
            if ( ( GetTickCount () - start_time ) > CMD_TIMEOUT )
            {
                failed = true;
                break;
            } // End if
        } // End while

            // If the attempt succeeded, a timeout did not occur and the response
        // can be read
        if ( failed == false )
        {
            timeout = false;
            break;
        } // End if
    } // End for

    // If a timeout occured, do not wait for the rest of the packet. Return
    // an error packet immediately
    if ( timeout == true )
    {
        packet_in  = 0;
        packet_in |= ( STATUS_TIMEOUT << 28 );
        return ( packet_in );
    } // End if
    
    // Pull the strobe line high to indicate the response can be sent
    SetPortVal ( g_lpt_out, PIN_STROBE, 1 );      // Emit the signal
    Delay_us   ( DEL_HOLD );                      // Hold
    SetPortVal ( g_lpt_out, PIN_NULL, 1 );        // Clear the signal
    Delay_us   ( DEL_HOLD );                      // Hold

    // Clear the packet buffer
    packet_in = 0;

    // Register to store the next bit as its read
    int next_bit = 0;

    // Begin reading the response from the programmer
    for ( int b = 0; b < 32; b++ )
    {
        // Clock the programmer for the next bit
        SetPortVal ( g_lpt_out, PIN_CLOCK, 1 ); // Set the clock
        Delay_us   ( DEL_HOLD );                // Hold
        
        // Read the bit and add it to the packet buffer
        GetPortVal ( g_lpt_in, &inp, 1 );
        next_bit   = ( inp & PIN_DATA_IN ) != 0 ? 1 : 0;
        packet_in |= next_bit << b;

        // Clear the clock to create an even duty cycle
        SetPortVal ( g_lpt_out, PIN_NULL, 1 );  // Clear the clock
        Delay_us   ( DEL_HOLD );                // Hold
    } // End while

    // Get the status code. If a valid code was not returned, consider it a timeout
    int status = SX_GET_RESPONSE_STATUS ( packet_in );
    if ( status != STATUS_SUCCESS && status != STATUS_ERROR )
        packet_in |= ( STATUS_TIMEOUT << 28 );

    // Return the response packet
    return ( packet_in );
} // End Send_Prog_Cmd ()

/******************************************************************************
*
*   Delay_us ()
*
*   Microsecond delay.
*/

void Delay_us ( int del )
{
    // Loop for <del> microseconds
    for ( int i = 0; i < del; i++ )
    {
        int t_curr, t_end;

        // Calculate end time of delay
        _asm
        {
            RDTSC
            MOV     t_end, EAX
        } // End asm
        t_end += g_del_us;

        // Loop until the end of the microsecond
        while ( true )
        {
            _asm
            {
                RDTSC
                MOV     t_curr, EAX
            } // End asm

            if ( t_curr > t_end )
                break;
        } // End while
    } // End for
} // End Delay_us ()

/******************************************************************************
*
*   Get_Hex_Digit ()
*
*   Converts an ASCII-formatted hex digit into its actual value.
*/

int Get_Hex_Digit ( char x )
{
    // Is the digit between 0 and 9?
    if ( x >= '0' && x <= '9' ) return ( x - '0' );

    // Is the digit between A and F (uppercase)?
    if ( x >= 'A' && x <= 'F' ) return ( x - 'A' + 10 );

    // Is the digit between a and f (lowercase)?
    if ( x >= 'a' && x <= 'f' ) return ( x - 'a' + 10 );

    // Anything else is invalid
    return ( 0 );
} // End Get_Hex_Digit ()

/******************************************************************************
*
*   SX_Init ()
*
*   Initializes the SX ISP library.
*/

bool SX_Init ( int device, char *config_file )
{
    // **** INITIALIZE WINIO LIBRARY ******************************************
    
    // Code taken from WinIO example
    DWORD  dwPortVal;
    DWORD  dwMemVal;
    bool   bResult;
    HANDLE hPhysicalMemory;
    PBYTE  pbLinAddr;
    bResult = InitializeWinIo();
    if ( bResult == 1 )
    {
        GetPortVal(0x378, &dwPortVal, 4);
        SetPortVal(0x378, 10, 4);
        pbLinAddr = MapPhysToLin((PBYTE)0xA0000, 65536, &hPhysicalMemory);
        if (pbLinAddr)
        {
          *pbLinAddr = 10;
          UnmapPhysicalMemory(hPhysicalMemory, pbLinAddr);
        }
        GetPhysLong((PBYTE)0xA0000, &dwMemVal);
        SetPhysLong((PBYTE)0xA0000, 10);

        // **** Success
    }
    else
    {
        // **** Failure
        return ( false );
    } // End if
    
    // **** INITIALIZE PARALLEL PORT ******************************************

    // Set the parallel port in/out addresses
    g_lpt_out = 0x378;
    g_lpt_in  = 0x379;

    // **** INITIALIZE TIMING *************************************************

    // Timing endpoints
    unsigned int t0, t1, td;

    // Get timestamp
    _asm
    {
        RDTSC
        MOV     t0, EAX
    } // End asm

    // Wait for 1000ms to ensure an accurate timing period accross all systems
    Sleep ( 1000 );

    // Get timestamp
    _asm
    {
        RDTSC
        MOV     t1, EAX
    } // End asm

    // Get the time difference
    td = t1 - t0;

    // Divide by 1000 to determine the number of clocks in a millisecond
    g_del_ms = ( unsigned int )( ( ( float )td )       / ( ( float )1000 ) );
    g_del_us = ( unsigned int )( ( ( float )g_del_ms ) / ( ( float )1000 ) );   

    // **** CONFIGURE *********************************************************

    // Set repetition counts
    g_sx_config.rep_load_data  = DEF_REP_LOAD_DATA;
    g_sx_config.rep_erase      = DEF_REP_ERASE;
    g_sx_config.rep_prog_mem   = DEF_REP_PROG_MEM;
    g_sx_config.rep_prog_fusex = DEF_REP_PROG_FUSEX;
    g_sx_config.rep_prog_fuse  = DEF_REP_PROG_FUSE;

    // Set verification settings
    g_sx_config.write_verify_freq = DEF_WRITE_VERIFY_FREQ;

    // **** LOAD CONFIG FILE IF FOUND *****************************************

    // Input buffers for reading lines from the file
    char input [ 256 ];
    char key   [ 64 ],
         value [ 64 ];

    // Character indices
    unsigned int c0, c1;

    // Is a configuration file present?
    FILE *fp = fopen ( "sx_api_config.ini", "r" );

    // If the file exists, read it in and override the existing settings
    if ( fp != NULL )
    {
        // Load each line of the file
        while ( ! feof ( fp ) )
        {
            // Read the next line
            fgets ( input, 256, fp );

            // Clip the line at the first semicolon character to remove the comment
            for ( c0 = 0; c0 < strlen ( input ); c0++ )
                if ( input [ c0 ] == ';' )
                    input [ c0 ] = '\0';

            // Get the key (every non-whitespace character to the = sign)
            c1 = 0;
            for ( c0 = 0; c0 < strlen ( input ); c0++ )
            {
                if ( input [ c0 ] == '=' )
                    break;
                else if ( input [ c0 ] != ' ' && input [ c0 ] != '\t' )
                    key [ c1++ ] = input [ c0 ];
            } // End for
            key [ c1 ] = '\0';

            // Move past the equal sign
            c0++;

            // Get the value (every non-whitespace character to the end of the string)
            c1 = 0;
            for ( ; c0 < strlen ( input ); c0++ )
            {
                if ( input [ c0 ] != ' ' &&
                     input [ c0 ] != '\t' &&
                     input [ c0 ] != '\n' )
                    value [ c1++ ] = input [ c0 ];
            } // End for
            value [ c1 ] = '\0';

            // If a valid key and value were read, assign them to configuration settings
            if ( strlen ( key ) > 0 && strlen ( value ) > 0 )
            {
                if ( stricmp ( key, "REP_LOAD_DATA" ) == 0 )
                    g_sx_config.rep_load_data = atoi ( value );

                else if ( stricmp ( key, "REP_ERASE" ) == 0 )
                    g_sx_config.rep_erase = atoi ( value );

                else if ( stricmp ( key, "REP_PROG_MEM" ) == 0 )
                    g_sx_config.rep_prog_mem = atoi ( value );

                else if ( stricmp ( key, "REP_PROG_FUSEX" ) == 0 )
                    g_sx_config.rep_prog_fusex = atoi ( value );

                else if ( stricmp ( key, "REP_PROG_FUSE" ) == 0 )
                    g_sx_config.rep_prog_fuse = atoi ( value );

                else if ( stricmp ( key, "WRITE_VERIFY_FREQ" ) == 0 )
                    g_sx_config.write_verify_freq = atoi ( value );
            } // End if
        } // End while
    } // End if

    // **** INITIALIZE DEVICE *************************************************

    // Initialize the representation of the hardware
    SX_Set_Device   ( device );
    SX_Erase_Buffer ();

    return ( true );
} // End SX_Init ()

/******************************************************************************
*
*   SX_Shut_Down ()
*
*   Shuts down the SX ISP library.
*/

bool SX_Shut_Down ()
{
    return ( true );
} // End SX_Shut_Down ()

/******************************************************************************
*
*   SX_Set_Device ()
*
*   Sets the current device and its attributes.
*/

void SX_Set_Device ( int device )
{
    // Set the device code itself
    g_sx_device.type = device;

    // Set the device based on the code
    switch ( device )
    {
        case SX_DEVICE_SX18:
            strcpy ( g_sx_device.name_string, "SX18" );
            g_sx_device.program_size = SX_MEM_182028;
            break;

        case SX_DEVICE_SX20:
            strcpy ( g_sx_device.name_string, "SX20" );
            g_sx_device.program_size = SX_MEM_182028;
            break;    

        case SX_DEVICE_SX28:
            strcpy ( g_sx_device.name_string, "SX28" );
            g_sx_device.program_size = SX_MEM_182028;
            break;        

        case SX_DEVICE_SX48:
            strcpy ( g_sx_device.name_string, "SX48" );
            g_sx_device.program_size = SX_MEM_4852;
            break;        

        case SX_DEVICE_SX52:
            strcpy ( g_sx_device.name_string, "SX52" );
            g_sx_device.program_size = SX_MEM_4852;
            break;                    
    } // End switch
} // End SX_Set_Device ()

/******************************************************************************
*
*   SX_Init_ISP ()
*
*   Initializes the SX's ISP mode.
*/

SX_CMD SX_Init_ISP ()
{
    // Initialize ISP mode
    SX_CMD status = Send_Prog_Cmd ( CMD_INIT_ISP, 0, 0, 0, 0, 0 );

    // Reset the memory pointer
    g_sx_device.mem_ptr       = 0;
    g_sx_device.mem_ptr_moved = false;

    return ( status );
} // End SX_Init_ISP ()

/******************************************************************************
*
*   SX_Shut_Down_ISP ()
*
*   Shuts down ISP mode.
*/

SX_CMD SX_Shut_Down_ISP ()
{
    // Shut down the ISP mode
    SX_CMD status = Send_Prog_Cmd ( CMD_SHUT_DOWN_ISP, 0, 0, 0, 0, 0 );

    return ( status );
} // End SX_Shut_Down_ISP ()

/******************************************************************************
*
*   SX_Erase_Buffer ()
*
*   Erases the local program memory.
*/

void SX_Erase_Buffer ()
{
    // Erase the configuration registers
    g_sx_device.fuse   = 0xFFF;
    g_sx_device.fusex  = 0xFFF;
    g_sx_device.device = 0xFFF;

    // Set each value in the buffer to $FFF, the SX's native unused value
    for ( int i = 0; i < SX_PROGRAM_SIZE; i++ )
        g_sx_device.program [ i ] = 0xFFF;
} // End SX_Erase_Buffer ()

/******************************************************************************
*
*   SX_Map_Code_Runs ()
*
*   Map the solid/empty runs throughout the program code.
*/

void SX_Map_Code_Runs ()
{
    int  run_index = 0;                     // Index of next run to use
    bool is_clear;                          // Is this a run of clear words ($FFF)?

    // Determine the first run type
    if ( ( g_sx_device.program [ 0 ] & 0xFFF ) == 0xFFF )
        is_clear = true;
    else
        is_clear = false;

    // Scan through the program code for runs
    for ( int i = 0; i < SX_PROGRAM_SIZE; i++ )
    {
        // If no free runs are left, force the last run to contain the rest of the code
        if ( run_index == MAX_PROGRAM_RUN_COUNT - 1 )
            g_sx_device.run_map [ run_index ].end = SX_PROGRAM_SIZE - 1;

        // Stop scanning when all runs are tracked
        if ( run_index >= MAX_PROGRAM_RUN_COUNT )
            break;

        // Read the next program word
        SX_WORD w = g_sx_device.program [ i ] & 0xFFF;

        // If the word is the opposite of the word expected, or the end of the
        // code has been reached, the run has ended
        if ( ( w == 0xFFF && is_clear == false ) ||
             ( w != 0xFFF && is_clear == true  ) ||
             ( i == ( SX_PROGRAM_SIZE - 1 ) ) )
        {
            // Mark the end of the run
            g_sx_device.run_map [ run_index ].end      = i - 1;
            g_sx_device.run_map [ run_index ].is_clear = is_clear;

            // Count the run
            g_sx_device.run_count++;

            // Move to the next run
            run_index++;          
           
            // Toggle the run type
            if ( is_clear == true ) is_clear = false; else is_clear = true;
        } // End if
    } // End while
} // End SX_Map_Code_Runs ()

/******************************************************************************
*
*   SX_Load_SXH_File ()
*
*   Loads an SXH hex file into the program memory buffer.
*/

bool SX_Load_SXH_File ( char *filename )
{
    // Open the file
    FILE *fp = fopen ( filename, "r" );

    // If the file could not be opened, return
    if ( fp == NULL )
        return ( false );

    // Erase the local buffer
    SX_Erase_Buffer ();

    // Assume the file was loaded successfully
    bool file_ok = true;

    // Record line buffer and index
    char         record [ 512 ];
    unsigned int i = 0;

    // Record header
    unsigned int data_count  = 0;
    unsigned int base_addr   = 0;
    unsigned int record_type = 0;

    // Read each line of the file
    while ( ! feof ( fp ) )
    {
        // Read the next line (record) into a local buffer
        fgets ( record, 512, fp );

        // Clip the line at the first $0D character
        for ( i = 0; i < strlen ( record ); i++ )
        {
            // If an $0D is read, clip the string
            if ( record [ i ] == 0x0D )
            {
                record [ i ] = '\0';
                break;
            } // End if
        } // End for

        i = 0;          // Reset the line buffer index

        // If the length of the line is not enough to hold at least a valid
        // header, it's invalid
        if ( strlen ( record ) < 7 )
        {
            file_ok = false;
            break;
        } // End if

        // Verify the initial colon
        if ( record [ i++ ] != ':' )
        {
            file_ok = false;
            break;
        } // End if

        // Read the data count
        data_count  = Get_Hex_Digit ( record [ i++ ] ) << 4;
        data_count |= Get_Hex_Digit ( record [ i++ ] );

        // Read the base address of the block of values
        base_addr  = Get_Hex_Digit ( record [ i++ ] ) << 12;
        base_addr |= Get_Hex_Digit ( record [ i++ ] ) << 8;
        base_addr |= Get_Hex_Digit ( record [ i++ ] ) << 4;
        base_addr |= Get_Hex_Digit ( record [ i++ ] );

        // Halve the address, because the hex file specifies the location
        // within a byte buffer, not within the SX's 12-bit word space
        base_addr /= 2;
   
        // Read the record type
        record_type  = Get_Hex_Digit ( record [ i++ ] ) << 4;
        record_type |= Get_Hex_Digit ( record [ i++ ] );

        // If the record type is not recognized, an error has occured
        if ( record_type != 0x00 && record_type != 0x01 )
        {
            file_ok = false;
            break;
        } // End if

        // If the record type is end-of-file ($01), stop reading
        if ( record_type == 0x01 )
            break;

        // Calculated checksum, file checksum and temporary values
        unsigned int checksum      = 0;
        unsigned int file_checksum = 0;
        unsigned int v0, v1        = 0;

        // Start by reading the header into the checksum
        for ( i = 1; i < 8; i += 2 )
        {
            // Get the value
            v0  = Get_Hex_Digit ( record [ i ] ) << 4;
            v0 |= Get_Hex_Digit ( record [ i +  1 ] );

            // Add the value to the checksum
            checksum += v0;
        } // End for

        // Read the rest of the line; add each value to the checksum
        // and place it in memory
        for ( i = 9; i < strlen ( record ) - 3; i += 4 )
        {
            // Get the next 2 values
            v0  = Get_Hex_Digit ( record [ i ] )     << 4;
            v0 |= Get_Hex_Digit ( record [ i + 1 ] );
            v1  = Get_Hex_Digit ( record [ i + 2 ] ) << 4;
            v1 |= Get_Hex_Digit ( record [ i + 3 ] );
    
            // Add the values to the checksum
            checksum += v0 + v1;

            // Add the word to memory and truncate the value to 12 bits
            g_sx_device.program [ base_addr++ ] = ( v0 + ( v1 << 8 ) ) & 0xFFF;
        } // End for

        // Get the 8-bit two's compliment of the checksum
        checksum &= 0xFF;
        checksum  = ( ~checksum + 1 ) & 0xFF;

        // Get the file's checksum
        file_checksum  = Get_Hex_Digit ( record [ i++ ] ) << 4;
        file_checksum |= Get_Hex_Digit ( record [ i++ ] );

        // Verify the calculated checksum against the file's checksum
        if ( checksum != file_checksum )
        {
            file_ok = false;
            break;
        } // End if
    } // End while

    // Copy the FUSE and FUSEX registers from their location within the SXH hex image
    // to their properties within the device structure
    g_sx_device.fuse  = g_sx_device.program [ ADDR_FUSE ];
    g_sx_device.fusex = g_sx_device.program [ ADDR_FUSEX ];

    // Close the file
    fclose ( fp );

    // Map the program code's runs
    SX_Map_Code_Runs ();
  
    // Return the save status
    return ( file_ok );
} // End SX_Load_SXH_File ()

/******************************************************************************
*
*   SX_Save_SXH_File ()
*
*   Saves the program memory buffer to a hex file.
*/

bool SX_Save_SXH_File ( char *filename )
{
    // Open the file
    FILE *fp = fopen ( filename, "w" );

    // If the file could not be opened, return
    if ( fp == NULL )
        return ( false );

    // Assume the file was saved successfully
    bool file_ok = true;

    // Record line buffer and index
    char record [ 512 ];

    // Indices for program memory buffer and record buffer
    int rec_index  = 0;
    int prog_index = 0;

    // Program memory word, high and low order words
    int v0, v1;

    // Track the record's item count and checksum.
    int data_count = 0;
    int checksum   = 0;

    // **** WRITE THE PROGRAM MEMORY
    
    // Loop through the entire memory space for the selected chip
    while ( true )
    {
        // If the program index is out of the memory's range, stop writing
        if ( prog_index >= g_sx_device.program_size )
            break;

        // Start the record
        record [ 0 ] = ':';
        
        // Start the record index after the colon (1), data count (2), address (4),
        // and record type (2)
        rec_index = 1 + 2 + 4 + 2;

        // Write the base address of the row. Double the current index into the
        // memory to convert between a 12-bit (16-bit) program word address and
        // an byte hex file address.
        int base_addr = prog_index * 2;
        record [ 3 ] = SX_DEC_TO_HEX ( ( base_addr & 0xF000 ) >> 12 );
        record [ 4 ] = SX_DEC_TO_HEX ( ( base_addr & 0x0F00 ) >> 8 );
        record [ 5 ] = SX_DEC_TO_HEX ( ( base_addr & 0x00F0 ) >> 4 );
        record [ 6 ] = SX_DEC_TO_HEX ( ( base_addr & 0x000F ) );

        // Write the record type ($00)
        record [ 7 ] = '0';
        record [ 8 ] = '0';

        // Reset the data count and checksum. Start the checksum with the two
        // bytes of the address
        data_count = 0;
        checksum   = ( base_addr & 0x00FF ) + ( ( base_addr & 0xFF00 ) >> 8 );

        // Write the next line of up to 32 bytes out, and track how many bytes
        while ( true )
        {
            // If the record buffer is full, stop writing to it and dump it to the file
            if ( data_count >= 32 )
                break;

            // If the program index is still within range, write it
            if ( prog_index < g_sx_device.program_size )
            {
                // Get the next word from program memory
                v0 = g_sx_device.program [ prog_index ] & 0x00FF;
                v1 = ( g_sx_device.program [ prog_index ] & 0xFF00 ) >> 8;
                prog_index++;

                // Increment the data count twice since two bytes are being written
                data_count += 2;
                
                // Write the word to the record buffer with the low byte first
                record [ rec_index ]     = SX_DEC_TO_HEX ( ( v0 & 0xF0 ) >> 4 );
                record [ rec_index + 1 ] = SX_DEC_TO_HEX ( v0 & 0x0F );
                record [ rec_index + 2 ] = SX_DEC_TO_HEX ( ( v1 & 0xF0 ) >> 4 );
                record [ rec_index + 3 ] = SX_DEC_TO_HEX ( v1 & 0x0F );
                rec_index += 4;
                
                // Add each word to the checksum
                checksum += v0 + v1;
            } // End if
        } // End while

        // Add the data count to the checksum
        checksum += data_count;
       
        // Write the data count
        record [ 1 ] = SX_DEC_TO_HEX ( ( data_count & 0xF0 ) >> 4 );
        record [ 2 ] = SX_DEC_TO_HEX ( ( data_count & 0x0F ) );

        // Get the 8-bit two's compliment of the checksum
        checksum &= 0xFF;
        checksum  = ( ~checksum + 1 ) & 0xFF;

        // Write the checksum
        record [ rec_index++ ] = SX_DEC_TO_HEX ( ( checksum & 0xF0 ) >> 4 );
        record [ rec_index++ ] = SX_DEC_TO_HEX ( checksum & 0x0F );

        // End the line with CR/LF (in ASCII mode, the $0A will be translated to $0D0A automatically)
        record [ rec_index++ ] = 0x0A;

        // Terminate the record string
        record [ rec_index ] = '\0';

        // Write the line
        fputs ( record, fp );
    } // End while

    // **** WRITE THE FUSE/FUSEX RECORD

    // Start the checksum with the sum of the data count (4) and the base address ($2020)
    checksum = 4 + 0x20 + 0x20;

    // Add the 4 bytes of the FUSE and FUSEX words to the checksum
    checksum += ( g_sx_device.fuse  & 0x00FF ) + ( ( g_sx_device.fuse  & 0xFF00 ) >> 8 );
    checksum += ( g_sx_device.fusex & 0x00FF ) + ( ( g_sx_device.fusex & 0xFF00 ) >> 8 );

    // Write the leading colon
    record [ 0 ] = ':';
    
    // Write the data count
    record [ 1 ] = '0';
    record [ 2 ] = '4';
    
    // Write the base address
    record [ 3 ] = '2';
    record [ 4 ] = '0';
    record [ 5 ] = '2';
    record [ 6 ] = '0';

    // Write the record type
    record [ 7 ] = '0';
    record [ 8 ] = '0';

    // Write the FUSE word
    record [ 9 ]  = SX_DEC_TO_HEX ( ( g_sx_device.fuse & 0x00F0 ) >> 4 );
    record [ 10 ] = SX_DEC_TO_HEX (   g_sx_device.fuse & 0x000F );
    record [ 11 ] = SX_DEC_TO_HEX ( ( g_sx_device.fuse & 0xF000 ) >> 12 );
    record [ 12 ] = SX_DEC_TO_HEX ( ( g_sx_device.fuse & 0x0F00 ) >> 8 );

    // Write the FUSEX word
    record [ 13 ] = SX_DEC_TO_HEX ( ( g_sx_device.fusex & 0x00F0 ) >> 4 );
    record [ 14 ] = SX_DEC_TO_HEX (   g_sx_device.fusex & 0x000F );
    record [ 15 ] = SX_DEC_TO_HEX ( ( g_sx_device.fusex & 0xF000 ) >> 12 );
    record [ 16 ] = SX_DEC_TO_HEX ( ( g_sx_device.fusex & 0x0F00 ) >> 8 );

    // Get the 8-bit two's compliment of the checksum
    checksum &= 0xFF;
    checksum  = ( ~checksum + 1 ) & 0xFF;

    // Write the checksum
    record [ 17 ] = SX_DEC_TO_HEX ( ( checksum & 0xF0 ) >> 4 );
    record [ 18 ] = SX_DEC_TO_HEX ( checksum & 0x0F );

    // Write the CR/LF/String terminator
    record [ 19 ] = 0x0D;
    record [ 20 ] = 0x0A;
    record [ 21 ] = '\0';

    // Write the record
    fputs ( record, fp );

    // **** WRITE THE EOF RECORD

    strcpy ( record, ":00000001FF\0x0D\0x0A" );
    fputs ( record, fp );

    // Close the file
    fclose ( fp );

    // Return the load status
    return ( file_ok );
} // End SX_Save_SXH_File ()

/******************************************************************************
*
*   SX_Read_Program ()
*
*   Reads the program memory of the device into the program memory buffer.
*/

bool SX_Read_Program ( int *progress, SX_CMD *result )
{
    // Determine how many buffer-sized chunks exist within the program memory
    int buff_count = g_sx_device.program_size / SX_PROG_BUFFER_SIZE;

    // Is the operation done?
    bool is_done = false;

    // Track the memory pointer at the start and end of the operation
    int start_mem_ptr = g_sx_device.mem_ptr;

    // Before altering the memory pointer, determine if the end of memory has
    // been reached without a wrap-around
    if ( g_sx_device.mem_ptr >= g_sx_device.program_size - 1 )
        is_done = true;
    else
        is_done = false;

    // Stream the next chunk into the programmer
    *result = SX_Stream_Buffer_In ( SX_PROG_BUFFER_SIZE );

    // Read each byte from the programmer
    for ( int i = 0; i < SX_PROG_BUFFER_BYTE_SIZE; i += 2, g_sx_device.mem_ptr++ )
        g_sx_device.program [ g_sx_device.mem_ptr ] = SX_GET_RESPONSE_DATA ( SX_Read_Buffer ( i ) );

    // If a wrap-around has occured, the end of memory has been reached
    if ( g_sx_device.mem_ptr < start_mem_ptr )
        is_done = true;

    // Return the progress
    *progress = ( ( float )( ( float )( g_sx_device.mem_ptr + 1 ) / ( float )g_sx_device.program_size ) ) * 100;

    return ( is_done );
} // End SX_Read_Program ()

/******************************************************************************
*
*   SX_Write_Program ()
*
*   Writes the contents of the program memory buffer to the device.
*/

bool SX_Write_Program ( int *progress, SX_CMD *result )
{
    int r          = 0;                         // Track code runs
    int block_size = 0;                         // Size of current block
    int block_end  = 0;                         // End of current block

    // Is the operation done?
    bool is_done = false;

    // Track the memory pointer at the start and end of the operation
    int start_mem_ptr = g_sx_device.mem_ptr;

    // Before altering the memory pointer, determine if the end of memory has
    // been reached without a wrap-around
    if ( g_sx_device.mem_ptr >= g_sx_device.program_size - 1 )
        is_done = true;
    else
        is_done = false;

    // Find the currently active code run
    for ( r = 0; r < g_sx_device.run_count; r++ )
        if ( g_sx_device.mem_ptr <= g_sx_device.run_map [ r ].end )
            break;

    // What kind of run is being output?
    if ( g_sx_device.run_map [ r ].is_clear == true )
    {
        // Get the size of the block to output
        block_size = ( g_sx_device.run_map [ r ].end - g_sx_device.mem_ptr ) + 1;

        // Clip the block at 4095 bytes
        if ( block_size > 4095 )
            block_size = 4095;

        // Clip the block size to the program memory size of the current device
        if ( g_sx_device.mem_ptr + block_size > ( g_sx_device.program_size ) )
            block_size = g_sx_device.program_size - g_sx_device.mem_ptr;

        // Get the block endpoint
        block_end = ( g_sx_device.mem_ptr + block_size ) - 1;

        // The run is clear, so emit blanks until the run's endpoint
        SX_CMD q = SX_Inc_Mem_Ptr ( block_size );
        *result = q;
    }
    else
    {
        // Get the next buffer-sized block (or smaller, if not available)
        block_size = SX_PROG_BUFFER_SIZE;

        // Clip the block size to the current run
        if ( g_sx_device.mem_ptr + block_size > ( g_sx_device.run_map [ r ].end + 1 ) )
            block_size = ( g_sx_device.run_map [ r ].end - g_sx_device.mem_ptr ) + 1;

        // Clip the block size to the program memory size of the current device
        if ( g_sx_device.mem_ptr + block_size > ( g_sx_device.program_size ) )
            block_size = g_sx_device.program_size - g_sx_device.mem_ptr;

        // Get the block endpoint
        block_end = ( g_sx_device.mem_ptr + block_size ) - 1;

        // Write the block to the buffer
        for ( int j = 0; j < block_size; j++, g_sx_device.mem_ptr++ )
            *result = SX_Write_Buffer ( g_sx_device.program [ g_sx_device.mem_ptr ], j * 2 );

        // Stream the buffer to the target device
        *result = SX_Stream_Buffer_Out ( block_size );
    } // End if

    // If a wrap-around has occured, the end of memory has been reached
    if ( g_sx_device.mem_ptr < start_mem_ptr )
        is_done = true;

    // Return the progress
    *progress = ( ( float )( ( float )( g_sx_device.mem_ptr + 1 ) / ( float )g_sx_device.program_size ) ) * 100;

    // Return the status of the operation
    return ( is_done );
} // End SX_Write_Program ()

/******************************************************************************
*
*   SX_Erase_Device ()
*
*   Erases the program memory of the device.
*/

SX_CMD SX_Erase_Device ()
{
    // Run the erase command for the specified number of repetitions
    SX_CMD r = Send_Prog_Cmd ( CMD_SEND_ISP_CMD, g_sx_config.rep_erase, ISP_CMD_ERASE, 0x000, 0, 0 );

    return ( r );
} // End SX_Erase_Device ()

/******************************************************************************
*
*   SX_Inc_Mem_Ptr ()
*
*   Increments the SX memory pointer by the specified count.
*/

SX_CMD SX_Inc_Mem_Ptr ( int count )
{
    // Has the memory pointer been moved yet?
    if ( g_sx_device.mem_ptr_moved == false )
    {
        // No, so move it from the FUSE register to zero
        g_sx_device.mem_ptr = 0;

        // The memory pointer is now within the valid address space
        g_sx_device.mem_ptr_moved = true;
    }
    else
    {
        // Yes, so increment the memory pointer and wrap around if necessary
        g_sx_device.mem_ptr += count;
        if ( g_sx_device.mem_ptr >= g_sx_device.program_size )
            g_sx_device.mem_ptr = 0;
    } // End if

    // Move to the new address in memory on the device
    SX_CMD r;
    int    count_div = count / 255;
    int    count_mod = count % 255;
    for ( int i = 0; i < count_div; i++ )
        r = Send_Prog_Cmd ( CMD_INC_MEM_PTR, 255, 0, 0, 0, 0 );
    r = Send_Prog_Cmd ( CMD_INC_MEM_PTR, count_mod, 0, 0, 0, 0 );

    return ( r );
} // End SX_Inc_Mem_Ptr ()

/******************************************************************************
*
*   SX_Read ()
*
*   Reads from the current memory location and increments the pointer.
*/

SX_CMD SX_Read ()
{
    // Read the register
    SX_CMD read_res = Send_Prog_Cmd ( CMD_SEND_ISP_CMD, 1, ISP_CMD_READ_MEM, 0x000, 0, 0 );

    // Move to the next location
    SX_CMD r = SX_Inc_Mem_Ptr ( 1 );
    if ( SX_CMD_FAILED ( r ) == true )
        return ( r );

    return ( read_res );
} // End SX_Read ()

/******************************************************************************
*
*   SX_Write ()
*
*   Writes the specified word to the current memory location and increments
*   the pointer.
*/

SX_CMD SX_Write ( SX_WORD x, bool verify )
{  
    SX_CMD r;                                              // Response

    // Load the word into the data register
    r = Send_Prog_Cmd ( CMD_SEND_ISP_CMD, g_sx_config.rep_load_data, ISP_CMD_LOAD_DATA, x, 0, 0 );

    // Program the memory location
    // The value of <g_sx_config.rep_prog_fuse> is used as the rep count here because this function
    // is only used to write the FUSE register; all other program memory locations are written to
    // with the Stream_Buffer_Out () function and have their own rep count value.
    r = Send_Prog_Cmd ( CMD_SEND_ISP_CMD, g_sx_config.rep_prog_fuse, ISP_CMD_PROG_MEM, 0x000, 0, 0 );

    // Verify the memory location
    if ( verify == true )
    {
        // Read the memory location
        r = Send_Prog_Cmd ( CMD_SEND_ISP_CMD, 1, ISP_CMD_READ_MEM, 0x000, 0, 0 );

        // If the write failed, return the error
        if ( SX_CMD_FAILED ( r ) == true )
            return ( r );

        // If the value read does not match the value written, an error has occured
        if ( SX_GET_RESPONSE_DATA ( r ) != x )
        {
            r |= ( STATUS_ERROR << 28 );
            return ( r );
        } // End if
    } // End if

    // Move to the next location
    r = SX_Inc_Mem_Ptr ( 1 );

    return ( r );
} // End SX_Write ()

/******************************************************************************
*
*   SX_Read_FUSE ()
*
*   Reads the current memory location, increments the pointer, and stores the
*   value in the local FUSE register buffer.
*/

SX_CMD SX_Read_FUSE ()
{
    // Read the register
    SX_CMD r = Send_Prog_Cmd ( CMD_SEND_ISP_CMD, 1, ISP_CMD_READ_MEM, 0x000, 0, 0 );

    // Set the FUSE register
    g_sx_device.fuse = SX_GET_RESPONSE_DATA ( r );

    // Move to the next location
    r = SX_Inc_Mem_Ptr ( 1 );

    return ( r );
} // End SX_Read_FUSE ()

/******************************************************************************
*
*   SX_Write_FUSE ()
*
*   Writes the FUSE register to the current memory location and increments the
*   pointer.
*/

SX_CMD SX_Write_FUSE ()
{
    return ( SX_Write ( g_sx_device.fuse, true ) );
} // End Write_FUSE ()

/******************************************************************************
*
*   SX_Read_FUSEX ()
*
*   Returns the FUSEX register.
*/

SX_CMD SX_Read_FUSEX ()
{
    // Read the FUSEX register
    SX_CMD r = Send_Prog_Cmd ( CMD_SEND_ISP_CMD, 1, ISP_CMD_READ_FUSEX, 0x000, 0, 0 );

    // Copy the response packet's data into the local buffer's FUSEX register
    g_sx_device.fusex = SX_GET_RESPONSE_DATA ( r );

    return ( r );
} // End SX_Read_FUSEX ()

/******************************************************************************
*
*   SX_Write_FUSEX ()
*
*   Programs the FUSEX register.
*/

SX_CMD SX_Write_FUSEX ()
{
    // Load the FUSEX settings into the data register
    Send_Prog_Cmd ( CMD_SEND_ISP_CMD, g_sx_config.rep_load_data, ISP_CMD_LOAD_DATA, g_sx_device.fusex, 0, 0 );

    // Program the FUSEX register
    Send_Prog_Cmd ( CMD_SEND_ISP_CMD, g_sx_config.rep_prog_fusex, ISP_CMD_PROG_FUSEX, 0x000, 0, 0 );

    // Complete the process by reading the FUSEX register at least once
    SX_CMD r = Send_Prog_Cmd ( CMD_SEND_ISP_CMD, 1,  ISP_CMD_READ_FUSEX, 0x000, 0, 0 );

    return ( r );
} // End SX_Write_FUSEX ()

/******************************************************************************
*
*   SX_Read_DEVICE ()
*
*   Returns the FUSE register.
*/

SX_CMD SX_Read_DEVICE ()
{
    // Read the FUSEX register
    int r = Send_Prog_Cmd ( CMD_SEND_ISP_CMD, 1, ISP_CMD_READ_DEVICE, 0x000, 0, 0 );

    // Copy the response packet's data into the local buffer's FUSEX register
    g_sx_device.device = SX_GET_RESPONSE_DATA ( r );

    // Set the device
    if ( g_sx_device.device == SX_DEVICE_REG_SX182028 )
        SX_Set_Device ( SX_DEVICE_SX28 );
    else
        SX_Set_Device ( SX_DEVICE_SX52 );

    return ( r );
} // End SX_Read_DEVICE ()

/******************************************************************************
*
*   SX_Write_Buffer ()
*
*   Writes a word to the specified location within the buffer.
*/

SX_CMD SX_Write_Buffer ( SX_WORD data, int addr )
{
    SX_CMD r = Send_Prog_Cmd ( CMD_WRITE_BUFFER, 0, 0, 0, data, addr );
    return ( r );
} // End SX_Write_Buffer ()

/******************************************************************************
*
*   SX_Read_Buffer ()
*
*   Writes a word to the specified location within the buffer.
*/

SX_CMD SX_Read_Buffer ( int addr )
{
    SX_CMD r = Send_Prog_Cmd ( CMD_READ_BUFFER, 0, 0, 0, 0, addr );
    return ( r );
} // End SX_Read_Buffer ()

/******************************************************************************
*
*   SX_Stream_Buffer_Out ()
*
*   Streams the contents of the buffer to the target device.
*/

SX_CMD SX_Stream_Buffer_Out ( int size )
{
    SX_CMD r = Send_Prog_Cmd ( CMD_STREAM_BUFFER_OUT, g_sx_config.rep_prog_mem, 0, size, 0, 0 );
    return ( r );
} // End SX_Stream_Buffer_Out ()

/******************************************************************************
*
*   SX_Stream_Buffer_In ()
*
*   Streams the contents of the target device to the buffer.
*/

SX_CMD SX_Stream_Buffer_In ( int size )
{
    SX_CMD r = Send_Prog_Cmd ( CMD_STREAM_BUFFER_IN, 0, 0, size, 0, 0 );
    return ( r );
} // End SX_Stream_Buffer_In ()