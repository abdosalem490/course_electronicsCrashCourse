XGS-ME TILE GRAPHICS ENGINE
Version 1.3.1
Alex Varanese
1.27.2005
-------------------------------------------------------------------------------

This is a tile-based graphics system that makes it easy to create complex,
graphically-detailed games on the XGameStation Micro Edition. Instead of
directly generating the TV signal, client programs manipulate a framebuffer
stored in SRAM.

THE ENGINE
--------------------------------------------------------------------------------

XGS_ME_TILE_GFX_ENGINE_1_3_1.SRC is a "skeleton" you can use to make your own
games and demos. Read the comments in this file and fill in your own code. It's
that easy! :)

THE DEMOS
--------------------------------------------------------------------------------

Text Command Console
	TEXT_CONSOLE_1_0.SRC
	(Uses Engine 1.3.1)
	
	Presents a command-line style interface in which commands can be entered
	with the keyboard and executed.

Scrolling Demo
	SCROLL_TEST.SRC
	(Uses Engine 1.3.1)
	
	A simple example of the new moveable visible buffer in version 1.3.1 of
	the tile engine. Use the joystick to scroll up and down through 10
	(repeating) screens of playfield graphics. Note that the entire SRAM
	can be scrolled through, including the areas not filled with graphics.
	Also demonstrates a simple way to achieve static lightinge effecfs.

Pitfall!
	PITFALL_0_8.SRC
	(Uses Engine 1.2)
	
	This is the start of a Pitfall clone that features the majority of the
	game's visuals and the beginnings of its gameplay.
	
Venture
	VENTURE_1_0.SRC
	(Uses Engine 1.2)
	
	Explore a castle inhabited by three dragons and collect the items
	necessary to unlock the main gate. Features detailed graphics, large
	enemy sprites, color effects and more!

XGS Bros.
	XGS_BROS_1_0.SRC
	(Uses Engine 1.1)

	A platformer demo done in the style of Mario Bros (obviously). Has a
	title screen, three screens of backgrounds, collision detection,
	gravity, animated and moving enemies, and even a fire flower power-up!
	
Shooter Demo
	SHOOTER_1_0.SRC
	(Uses Engine 1.0)

	A simple demo of a defender-style spaceship engine, minus the scrolling.
	
THE SX/B BASIC DEMOS
--------------------------------------------------------------------------------

The following demos were created using the Tile Engine integrated with the SX/B
BASIC compiler from Parallax Corporation.

Pong
	SXB/PONG/SXB_PONG_1_0.SXB
	(Uses Engine 1.3.1)
	
	A simple Pong game in which a ball is bounced between two paddles. The
	paddles are oriented vertically rather than horizontally to take advantage
	of the extra vertical resolution provided by the 16x24 tile screen.
	
Breakout
	SXB/BREAKOUT/SXB_BREAKOUT_0_8.SXB
	(Uses Engine 1.3.1)
	
	A Breakout clone with multiple levels, colorful graphics, and sound effects!

Frogger
	SXB/BREAKOUT/SXB_FROGGER_0_2.SXB
	(Uses Engine 1.3.1)
	
	The beginnings of a Frogger clone with the majority of the game's graphics
	faithfully ported to the Tile Graphics Engine. Currently features scrolling
	graphics (thanks to a custom assembly routine for scrolling rows of tiles
	horizontally) and a moveable frog.

CHANGE LOG
--------------------------------------------------------------------------------

	VERSION 1.3.1 - 1.27.2005
	
		- Fixed a simple timing error that prevented many TVs from
		  displaying certain programs correctly.
		- Added three basic demos written with the tile engine and the
		  SX/B BASIC compiler: Pong, Breakout and Frogger.

	VERSION 1.3 - 1.6.2005
	
		- Visible buffer in SRAM now moveable. Use the <visible_page_hi>
		  and <visible_page_hi> to specify the 12-bit page address of
		  the visible buffer.
		- All tile drawing functions can now draw anywhere in the SRAM,
		  by setting the 16-bit base address of the active screen with
		  <active_page_hi> and <active_page_lo>.
		- Get_Tile_Index() now requires that the video bank is active.

	VERSION 1.2 - 12.9.2004
	
		- Significantly optimized key tile-related functions for speed,
		  allowing full-screen updates with multiple foreground objects
		  to run much more efficiently alongside complex game logic.
		- Set_Tile_FG() subroutine added, allowing tiles to be drawn
		  without disturbing the existing background color (good for
		  foreground game objects).
		- Set_Tile() & Set_Tile_FG() now automatically clip to the
		  bounds of the framebuffer.

	VERSION 1.1 - 12.6.2004
	
		- Added support for up to 64 unique tile bitmaps (up from 32).
		- Game_Update() now has over 60,600 clock cycles in which to
		  execute.
		- Load_Map() subroutine added, allowing maps to be stored in a
		  small memory footprint and loaded at will.
		- Copy_Screen() subroutine added, allowing multiple framebuffers
		  to be used and displayed.
		- Get_Tile_Index() subroutine added, allowing a tile's bitmap
		  index to be read from an SRAM framebuffer.
		  
	VERSION 1.0 - 12.2.2004
	
		- Initial release.

BUG REPORTS
--------------------------------------------------------------------------------

Please send all bug reports to:

	support@nurve.net

XGAMESTATION ONLINE
--------------------------------------------------------------------------------

	http://www.xgamestation.com/